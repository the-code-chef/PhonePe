package com.example.phonepe.data.repository

import com.example.phonepe.data.model.Quiz
import com.example.phonepe.network.QuizDataSource
import com.example.phonepe.network.Response
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject

class QuizRepositoryImpl @Inject constructor(
    private val network: QuizDataSource,
    private val ioDispatcher: CoroutineDispatcher,
) : QuizRepository {
    override suspend fun getQuizList(): Flow<Response<List<Quiz>>> =
        withContext(ioDispatcher) {
            network.getQuizList()
        }
}
