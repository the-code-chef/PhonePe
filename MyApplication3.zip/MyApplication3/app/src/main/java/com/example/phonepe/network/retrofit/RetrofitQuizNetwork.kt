package com.example.phonepe.network.retrofit

import com.example.phonepe.data.model.Quiz
import com.example.phonepe.network.QuizDataSource
import com.example.phonepe.network.Response
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.http.GET
import javax.inject.Inject
import javax.inject.Singleton


private interface RetrofitQuizNetworkApi {
    @GET("phonepe")
    suspend fun getQuizList(): Flow<Response<List<Quiz>>>
}

@Serializable
private data class NetworkResponse<T>(
    val data: T,
)

@Singleton
class RetrofitQuizNetwork @Inject constructor(
    networkJson: Json,
    okHttpCallFactory: Call.Factory,
) : QuizDataSource {

    private val networkApi = Retrofit.Builder()
        .baseUrl("http://demo9894634.mockable.io/")
        .callFactory(okHttpCallFactory)
        .addConverterFactory(networkJson.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(RetrofitQuizNetworkApi::class.java)

    override suspend fun getQuizList(): Flow<Response<List<Quiz>>> = networkApi.getQuizList()
}
