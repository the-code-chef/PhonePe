package com.example.phonepe.data.repository

import com.example.phonepe.data.model.Quiz
import com.example.phonepe.network.Response
import kotlinx.coroutines.flow.Flow

interface QuizRepository {
    suspend fun getQuizList(): Flow<Response<List<Quiz>>>
}