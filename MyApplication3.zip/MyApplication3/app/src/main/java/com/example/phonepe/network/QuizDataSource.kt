package com.example.phonepe.network

import com.example.phonepe.data.model.Quiz
import kotlinx.coroutines.flow.Flow


interface QuizDataSource {
    suspend fun getQuizList(): Flow<Response<List<Quiz>>>
}
