package com.example.phonepe.ui

class QuizAdapter {
}