package com.example.phonepe.data.di

import com.example.phonepe.data.repository.QuizRepository
import com.example.phonepe.data.repository.QuizRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
interface DataModule {

    @Binds
    fun bindsQuizRepository(
        quizRepository: QuizRepositoryImpl
    ) : QuizRepository
}