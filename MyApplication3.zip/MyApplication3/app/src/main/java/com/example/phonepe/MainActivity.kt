package com.example.phonepe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.myapplication.R
import com.example.phonepe.ui.QuizViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch


/**
 * Logo Quiz

We would want you to build a simple Android game that shows logos and captures the response from the player. The aim of the game is to match the player's input with the name of the logo in the least time.


Rules:

We are providing a json which contains a list of logos. Each entry consists of the logo image URL and the correct name of the logo. You need to display the logos one by one and collect the answer from the player.
 */

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val quizViewModel: QuizViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val titleText = findViewById<TextView>(R.id.title)

        lifecycleScope.launch {
            quizViewModel.quizList.collect {
                if (it.isNotEmpty()) {
                    titleText.text = it[0].name
                }
            }
        }
    }
}