package com.example.phonepe.domain

import com.example.phonepe.data.model.Quiz
import com.example.phonepe.data.repository.QuizRepository
import com.example.phonepe.network.Response
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class QuizUseCase @Inject constructor(
    private val quizRepository: QuizRepository,
) {
    suspend operator fun invoke(): Flow<Response<List<Quiz>>> {
        return quizRepository.getQuizList()
    }

}