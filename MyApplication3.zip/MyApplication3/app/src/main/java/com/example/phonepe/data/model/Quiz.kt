package com.example.phonepe.data.model

data class Quiz(
    val imgUrl: String,
    val name: String,
)

